The two files for Ask it twice, AI Foundations, MIT Sloan Executive MBA, October 27, 2026.

A fictional company. The CFO's memo proposes a 12% price rise on the Mid tier and gives Finance's
numbers and the modeling rules; the VP of Sales's email replies with different numbers.
Attach both to a new chat in Round B.
