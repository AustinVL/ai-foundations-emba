Starter pack for Exercise Two, AI Foundations, MIT Sloan Executive MBA, September 19, 2026.

Ten public MIT Sloan EMBA pages, fetched September 18, 2026, saved as Markdown text.
Each file starts with its source address. Upload them to your claude.ai Project.

class-of-2028-program-calendar.md was transcribed from the published calendar graphic;
check dates against your own materials.
